/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.assignmentp1;

/**
 *
 * @author booki
 */
import java.util.ArrayList;
import java.util.Scanner;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
public class AssignmentP1 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        ArrayList<Login> users = new ArrayList<>();

        System.out.println("\nWelcome to our chat app 2026! Select options below:");

        while (true) {
            System.out.println("\nMain Menu:");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {

                case 1: // Register
                    System.out.print("Enter username: ");
                    String username = scanner.nextLine();

                    boolean validUsername = username.contains("_") && username.length() <= 5;
                    if (!validUsername) {
                        System.out.println("Username must contain '_' and be no longer than 5 characters.");
                        break;
                    }

                    System.out.print("Enter password: ");
                    String password = scanner.nextLine();

                    boolean validPassword = password.length() >= 8 &&
                            password.matches(".*[A-Z].*") &&
                            password.matches(".*\\d.*") &&
                            password.matches(".*[!@#$%^&*(),.?\":{}|<>].*");

                    if (!validPassword) {
                        System.out.println("Password must be at least 8 characters, include uppercase, number, and special character.");
                        break;
                    }

                    System.out.print("Enter SA phone number (e.g. +27712345678): ");
                    String phoneNumber = scanner.nextLine();

                    String regex = "\\+27[6-8][0-9]{8}";
                    if (!phoneNumber.matches(regex)) {
                        System.out.println("Invalid phone number format!");
                        break;
                    }

                    boolean userExists = users.stream()
                            .anyMatch(u -> u.getUsername().equals(username));

                    if (userExists) {
                        System.out.println("Username already exists.");
                        break;
                    }

                    users.add(new Login(username, password, phoneNumber));
                    System.out.println("User registered successfully!");
                    System.out.println("Welcome " + username + "! You can now log in.\n");

                    promptLogin(scanner, users);
                    break;

                case 2: // Login
                    if (users.isEmpty()) {
                        System.out.println("No users registered yet.");
                        break;
                    }

                    promptLogin(scanner, users);
                    break;

                case 3:
                    System.out.println("Goodbye!");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid option.");
            }
        }
    }

    // Login method
    private static void promptLogin(Scanner scanner, ArrayList<Login> users) {
        System.out.print("Enter username: ");
        String enteredUsername = scanner.nextLine();

        System.out.print("Enter password: ");
        String enteredPassword = scanner.nextLine();

        Login user = users.stream()
                .filter(u -> u.getUsername().equals(enteredUsername))
                .findFirst()
                .orElse(null);

        boolean loginStatus = user != null && user.loginUser(enteredPassword);

        if (user != null) {
            System.out.println(user.returnLoginStatus(loginStatus));
        } else {
            System.out.println("User not found.");
        }
    }
}

// Login class
class Login {
    private String username;
    private String passwordHash;
    private String phoneNumber;
    private byte[] salt;

    public Login(String username, String password, String phoneNumber) {
        this.username = username;
        this.salt = generateSalt();
        this.passwordHash = hashPassword(password, salt);
        this.phoneNumber = phoneNumber;
    }

    public String getUsername() {
        return username;
    }

    public boolean loginUser(String enteredPassword) {
        return this.passwordHash.equals(hashPassword(enteredPassword, salt));
    }

    public String returnLoginStatus(boolean status) {
        return status ? "Login successful!" : "Invalid username or password.";
    }

    // Hash password
    private String hashPassword(String password, byte[] salt) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(salt);

            byte[] hash = md.digest(password.getBytes());
            StringBuilder hexString = new StringBuilder();

            for (byte b : hash) {
                hexString.append(String.format("%02x", b));
            }

            return hexString.toString();

        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error hashing password", e);
        }
    }

    // Generate salt
    private byte[] generateSalt() {
        SecureRandom random = new SecureRandom();
        byte[] salt = new byte[16];
        random.nextBytes(salt);
        return salt;
    }
}
    

